<?php 
session_start();
include 'dbconfig.php';


 if(isset($_POST['changepass'])){
$username  = $_SESSION['username'];

 $oldpassword     = $_POST['oldpass'];
 $password        = $_POST['newpass'];
if ($_POST['newpass']==$_POST['renewpass'])
 {$oldpassword =  md5($oldpassword);
 $password  = md5($password); 
 
 $fetch_sql = "SELECT * FROM users WHERE username ='$username' AND  password='$oldpassword'" ;
 
 
     $result = mysqli_query($conn,$fetch_sql);
     $rows = $result->fetch_all(MYSQLI_ASSOC);
 
 
           if($rows)
       {
      $log_insert_query = "UPDATE users SET password='$password' where username ='$username'"; 
           $result1 =  mysqli_query($conn, $log_insert_query);
 
        // $msg="<strong>Success!</strong> password changed successfully";
             $_SESSION["msg"] = "<strong>Success!</strong> password changed successfully";
              Header( 'Location: changepassword.php');
 
 }
 else
       {
 
       // $msg="<strong>Oh snap!</strong> ERROR ! could not change password";
         $_SESSION["msg"] ="<strong>Oh snap!</strong> ERROR ! could not change password";
       Header( 'Location: changepassword.php' );
       }
 
 }
else{
      $_SESSION["msg"] ="<strong>ERROR!!</strong> Confirm Password does not match!!!";
       Header( 'Location: changepassword.php' );
}
 }




 if(isset($_POST['addnew'])){
$pubname    = $_POST['pubname'];

 $publink        = $_POST['publink'];

 $fetch_sql = "SELECT * FROM univspdetails WHERE spname ='$pubname' OR  entityid='$publink'" ;

  $result = mysqli_query($conn,$fetch_sql);
  $rows = $result->fetch_all(MYSQLI_ASSOC);

       if($rows)
      {

       $_SESSION["msg"]="<strong>Oh snap!</strong> Publisher or Link already exists";
     Header( 'Location: addpublisher.php?error=1&msg='.$msg );
      

}
else
      {

 $log_insert_query = "INSERT INTO univspdetails (spname, entityid) VALUES('$pubname','$publink')  "; 
          $result =  mysqli_query($conn, $log_insert_query);
print_r($result);

      $_SESSION["msg"]="<strong>successfully Added</strong>";
      Header( 'Location: addpublisher.php?error=1&msg='.$msg );
 // return $msg;
      }

 }



 if(isset($_POST['edit'])){
$username  = $_SESSION['username'];

 $editlink    = $_POST['editlink'];
 $editname        = $_POST['editname'];

$spname = $_POST['spname'];

 $fetch_sql = "SELECT * FROM univspdetails WHERE spname ='$spname'" ;


   $result = mysqli_query($conn,$fetch_sql);
   $rows = $result->fetch_all(MYSQLI_ASSOC);


       if($rows)


      { 
       
        if ($editname AND $editlink){
 $log_insert_query = "UPDATE univspdetails SET spname ='$editname', entityid = '$editlink' where spname ='$spname'"; 
           $result1 =  mysqli_query($conn, $log_insert_query);

        $_SESSION["msg"]="<strong>Success!</strong> Publisher details changed";
             Header( 'Location: editpublisher.php?success=1&msg='.$msg );

        }

      elseif ($editlink){
         $log_insert_query = "UPDATE univspdetails SET entityid = '$editlink' where spname ='$spname'"; 
           $result1 =  mysqli_query($conn, $log_insert_query);

        $_SESSION["msg"]="<strong>Success!</strong> Publisher link changed";
             Header( 'Location: editpublisher.php?success=1&msg='.$msg );
      }
      else{
        $log_insert_query = "UPDATE univspdetails SET spname ='$editname' where spname ='$spname'"; 
           $result1 =  mysqli_query($conn, $log_insert_query);

       $_SESSION["msg"]="<strong>Success!</strong> Publisher name changed";
             Header( 'Location: editpublisher.php' );
      }
      }        
else
      {

      $msg="<strong>Oh snap!</strong> ERROR ! could not change publisher";
      Header( 'Location: changepassword.php' );
      }



  }
               
 if(isset($_GET['delete']))
{
  
    $Id=$_GET['id'];
$log_insert_query = "DELETE FROM univspdetails where id ='$Id'"; 
           $result1 =  mysqli_query($conn, $log_insert_query);

// $sql_query = "DELETE FROM univspdetails WHERE id='$Id'";
//     $retval =  mysqli_query($conn,$sql_query)
    
    if(! $result1 ) {
$_SESSION["msg"] ="<strong>Oh snap!</strong> ERROR ! could not delete data";
  // $msg="<strong>Oh snap!</strong> ERROR ! could not delete data";
      Header( 'Location: statistics.php' );
   }else{
   $_SESSION["msg"] =" Deleted successfully";
   // $msg="<strong>SUCCESS</strong> Deleted successfully";
   Header( 'Location: statistics.php') ;
  }
   
}
 
?>



