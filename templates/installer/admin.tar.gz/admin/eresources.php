<?php
  include 'dbconfig.php';
  include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    header( 'Location: login.php' );
   }
   ?>
	


<!-- <div id="main"> -->
    <!-- <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span> -->
<!-- <div class="w3-container " >
  <div class=" w3-display-middle w3-card-4 w3-border mobcss" style="box-shadow: 10px 10px 250px #00ADEF;">
    
    <div class="w3-container" >

    
    </div>



  </div>
  
</div> -->

<!-- <h1 class="headings">E-resources</h1> -->
</div>

<div class="box">
   <div class="msg-container" id="msg">

    <?php if(isset($_SESSION["msg"])){ ?>
    <div class="msg-box" id="success_msg" >
      <h4><?php echo $_SESSION["msg"];?><i class = "fa fa-close" style="float: right" onclick="closemsg()"></i></h4>
        <?php unset($_SESSION["msg"]) ?>
    </div>
    <?php } ?>
    </div>
<div class="tab">
 
  <button class="tablinks active" onclick="openCity(event, 'Adde')">Add E-resources</button>
 
    <button class="tablinks" onclick="openCity(event, 'Removee')">Delete E-resources</button>
     <!-- <button class="tablinks" style="float: right;"><a href="logout.php"><i class="fa fa-sign-out" style="font-size: 24px;color: black;" ></i></a></button> -->
    <!--  <button class="tablinks" style="float: right;">  <a href="index.php"><i class="fa fa-home" style="font-size: 24px;color: black;" ></i></a></button>
<div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn"><i class="fa fa-user"></i>&nbsp;Admin&nbsp;<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content">
     <a href = "changepassword.php" style="font-size: 16px;color: black;" ><i class="fa fa-key" ></i>Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" ><i class="fa fa-sign-out" ></i>Logout</a>
 
  </div>
</div> -->
</div>
<div id="Adde" class="tabcontent" style="display:block">
<div class="content">
  
<div class="single">
   
  <h3>Add E - Resources <div class="helptip" style="float:right"><i class="fa fa-question-circle" style="font-size:24px;"></i>
  <span class="helptiptext">Select the category . Enter the publisher name and there WAYFLess URL to show on IDP page</span>
</div></h3>
  <hr>
  
<form enctype='multipart/form-data' action='eresourcelogic.php' method='post' onSubmit="if(!confirm('Do you want to continue?')){return false;}">
    
<select id="category" name="category" class="form-control" data-msg-required="Please Select Category.">
    <option value="cat" disabled selected>Select Category</option>
    <option value="book">E-Book</option>
    <option value="database">E-Database</option>
    <option value="journal">E-Journal</option>
  </select>
<br>  
  <input type="text" class="form-control" placeholder="Enter Publisher Name" id="pubname" name="pubname" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter Enter Publisher Name."/>
<br>

<input type="text" class="form-control" placeholder="Enter Publisher's WAYFLess URL/Link" id="publink" name="publink" autofocus="autofocus" data-rule-required="true" data-msg-required="Enter Publisher's WAYFLess URL/Link"/>
 
  
</br>
 <button type="submit" id="addbtn" name="addbtn" class="add" ><i class="fa fa-add"></i>Submit</button>

</form>
</div>
</div>

</div>

<div id="Removee" class="tabcontent">
<div class="single">
<h3>Delete E - Resources
   <div class="helptip" style="float:right"><i class="fa fa-question-circle" style="font-size:24px;"></i>
  <span class="helptiptext">Select the E-Resources you want to delete from IDP page</span>
</div></h3>
  <hr>
  
<form enctype='multipart/form-data' action='eresourcelogic.php' method='post' onSubmit="if(!confirm('Do you want to continue?')){return false;}">
    

  
<select id="pubname" name="pubname" class="form-control" data-msg-required="Please Select Category.">

 <?php 

                                                        $sql = 'SELECT name FROM wayfless order by name';

                                                        $retval = mysqli_query($conn,$sql);

                                                        if(! $retval ) {
                                                            die('Could not get data: ' . mysql_error());
                                                        }

                                                        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
                                                            ?>  
                                                <option><?php echo $row['name']; ?> </option>

                                               
                            <?php         
                        }
                         ?>   
                          </select>


<br>
</br>
 <button type="submit" id="delbtn" name="delbtn" class="add" ><i class="fa fa-add"></i>Submit</button>

</form>
</div>
<!-- </div> -->

<script>
function closemsg (){
msg = document.getElementById("success_msg");
msg.style.display = "none";

}

</script>














