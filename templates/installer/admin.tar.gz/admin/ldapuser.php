<?php
  include 'dbconfig.php';
   session_start();
   if(isset($_POST['sendbtn'])){
         $handle = fopen($_FILES['filename']['tmp_name'], "r");
    $headers = fgetcsv($handle, 1000, ",");
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
    {
$u_email = $data[0];
$server = "ldap://localhost:389";
        $dn = "ou=People,dc=ignou,dc=ac,dc=in";
      error_reporting(0);
      ldap_connect($server);
      $con = ldap_connect($server);
      ldap_set_option($con, LDAP_OPT_PROTOCOL_VERSION, 3);
      $rootdn = "cn=admin,dc=ignou,dc=ac,dc=in";
        $rootpwd = "jdhg@ldap24jhsj";
      $user_search = ldap_search($con,$dn,"(|(cn=$u_email)(mail=$u_email)(givenName=$u_email)(uid=$u_email))");
      $user_get = ldap_get_entries($con, $user_search);
      $user_entry = ldap_first_entry($con, $user_search);
      $user_dn = ldap_get_dn($con, $user_entry);
      $user_id = $user_get[0]["uid"][0];
      $user_cn =  $user_get[0]["cn"][0];
 $r = ldap_bind($con,$rootdn,$rootpwd); 
        if ($r = ldap_delete($con,$user_dn) === false){
            $error = ldap_error($con);
        $errno = ldap_errno($con);
        $_SESSION["msg"] = "User can not be delete, please contact the administrator.";
        }
else{
   $_SESSION["msg"] = "User deleted successfully";  
}
      
}
header("Location:users.php");
}

if(isset($_POST['delbtn'])){
    $u_email = $_POST['u_name'];
$server = "ldap://localhost:389";
        $dn = "ou=People,dc=ignou,dc=ac,dc=in";
      error_reporting(0);
      ldap_connect($server);
      $con = ldap_connect($server);
      ldap_set_option($con, LDAP_OPT_PROTOCOL_VERSION, 3);
      $rootdn = "cn=admin,dc=ignou,dc=ac,dc=in";
        $rootpwd = "jdhg@ldap24jhsj";
      $user_search = ldap_search($con,$dn,"(|(cn=$u_email)(mail=$u_email)(givenName=$u_email)(uid=$u_email))");
      $user_get = ldap_get_entries($con, $user_search);
      $user_entry = ldap_first_entry($con, $user_search);
      $user_dn = ldap_get_dn($con, $user_entry);
      $user_id = $user_get[0]["uid"][0];
      $user_cn =  $user_get[0]["cn"][0];
 $r = ldap_bind($con,$rootdn,$rootpwd); 
        if ($r = ldap_delete($con,$user_dn) === false){
            $error = ldap_error($con);
        $errno = ldap_errno($con);
        $_SESSION["msg"] = "User can not be delete, please contact the administrator.";
        }
else{
   $_SESSION["msg"] = "User deleted successfully";  
}
      
header("Location:users.php");
}


 ?>

