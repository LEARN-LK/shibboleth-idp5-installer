<?php
  include 'dbconfig.php';
  include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    header( 'Location: login.php' );
   }
   ?>
<!-- <!DOCTYPE html>
<html>
<head>
<title>Admin</title>

<style type="text/css">
  .white-bg {
    height: inherit;
}

</style>
</head>
<body >
	 -->


<!-- <div id="main">

<div class="w3-container " >
  <div class=" w3-display-middle w3-card-4 w3-border mobcss" style="box-shadow: 10px 10px 250px #00ADEF;">
    
    



  </div>
  
</div> -->

<!-- <h1 class="headings">User Management</h1> -->


<div class="box">
<div class="msg-container" id="msg">

    <?php if(isset($_SESSION["msg"])){ ?>
    <div class="msg-box" id="success_msg" >
      <h4><?php echo $_SESSION["msg"];?><i class = "fa fa-close" style="float: right" onclick="closemsg()"></i></h4>
        <?php unset($_SESSION["msg"]) ?>
    </div>
    <?php } ?>
    </div>
  
<div class="content">
    
<div class="tab">

  <button class="tablinks active" onclick="openCity(event, 'Delete')">Delete Users</button>
 
    <button class="tablinks" onclick="openCity(event, 'Mail')">Send Notifications</button>
       <button class="tablinks">  <a href="https://idp.ignou.ac.in/ldap/templates/login.php" style="color: black;">Add User</a></button>
       <!-- <button class="tablinks" style="float: right;"><a href="logout.php"><i class="fa fa-sign-out" style="font-size: 24px;color: black;" ></i></a></button> -->
     <!-- <button class="tablinks" style="float: right;">  <a href="index.php"><i class="fa fa-home" style="font-size: 24px;color: black;" ></i></a></button>
<div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn"><i class="fa fa-user"></i>&nbsp;Admin&nbsp;<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content">
     <a href = "changepassword.php" style="font-size: 16px;color: black;" ><i class="fa fa-key" ></i>Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" ><i class="fa fa-sign-out" ></i>Logout</a> -->
 
  </div>
</div>
</div>



<div id="Delete" class="tabcontent" style="display:block">
 <?php include "deleteuser.php" ?>
</div>

<div id="Mail" class="tabcontent">
 <?php include "sendmail.php" ?>
</div>



<!-- </div> -->
</div>
</body>

<script>
function closemsg (){
msg = document.getElementById("success_msg");
msg.style.display = "none";

}

</script>

</html>







