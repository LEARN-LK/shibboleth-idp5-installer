<?php
  include 'dbconfig.php';
  include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    header( 'Location: login.php' );
   }
   ?>

<!-- <title>Admin</title>
<link rel="stylesheet" href="assets/css/stats.css">
<link rel="stylesheet" href="assets/css/home.css">
<script type="text/javascript" src="assets/js/stats.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/mail.css">

<link rel="stylesheet" href="assets/css/home.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->
<!-- <style type="text/css">
  .white-bg {
    height: inherit;
}


</style> -->
<!-- </head> -->
<body>
	


<!-- <div id="main"> -->
    <!-- <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span> -->
<!-- <div class="w3-container " >
  <div class=" w3-display-middle w3-card-4 w3-border mobcss" style="box-shadow: 10px 10px 250px #00ADEF;">
    
   


  </div>
  
</div>
 -->
<!-- <h1 class="headings">Statistics</h1> -->


<div class="box" >
<div class="msg-container" id="msg">

    <?php if(isset($_SESSION["msg"])){ ?>
    <div class="msg-box" id="success_msg" >
      <h4><?php echo $_SESSION["msg"];?><i class = "fa fa-close" style="float: right" onclick="closemsg()"></i></h4>
        <?php unset($_SESSION["msg"]) ?>
    </div>
    <?php } ?>
    </div>
  
<div class="content">
    
<div class="tab">
  <button class="tablinks active" onclick="openCity(event, 'Dashboard')">Dashboard</button>
  <button class="tablinks" onclick="openCity(event, 'User')">User Details</button>
   <button class="tablinks" onclick="openCity(event, 'Publisher')">Publisher Details</button>
    <div class="crumbs">

   <ul class="crumb-buttons">
      <li id="reportrange"> <a href="#">
         Select Date :                                                                
         <i class="icon-calendar">
         </i>
         <span>
         </span>
         <i class="icon-angle-down">
         </i>
         </a> 
      </li>
   </ul>
</div>
  <!-- <button class="tablinks" style="float: right;"><a href="logout.php"><i class="fa fa-sign-out" style="font-size: 24px;color: black;" ></i></a></button> --> 
     <!-- <button class="tablinks" style="float: right;">  <a href="index.php"><i class="fa fa-home" style="font-size: 24px;color: black;" ></i></a></button> -->

<!-- <div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn"><i class="fa fa-user"></i>&nbsp;Admin&nbsp;<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content">
     <a href = "changepassword.php" style="font-size: 16px;color: black;" ><i class="fa fa-key" ></i>Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" ><i class="fa fa-sign-out" ></i>Logout</a>
 
  </div>
</div> -->
</div>


<div id="Dashboard" class="tabcontent" style="display:block">
   <?php include "dashboard.php" ?>
</div>

<div id="User" class="tabcontent" style="margin-top:15%;">
  <?php include "userdetails.php" ?>
</div>

<div id="Publisher" class="tabcontent">
 <?php include "publisherlist.php" ?>
</div>


<!-- </div> -->
</div>
</body>

<script>
function closemsg (){
msg = document.getElementById("success_msg");
msg.style.display = "none";

}


   $(document).ready(function(){
if (document.getElementById(''))
    $.ajax({
      url:"getcontent.php",
      method: "POST",
      success: function(){
        task = 'fetch_all_logs';
        pageLoad();
      }
    });
       //pageLoad();
   });

/*date select start*/
   function cb(start, end) {
         $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
         document.getElementById("user").innerHTML = "";
           document.getElementById("rp").innerHTML = "";
         fetch_users_logs(start.format('YYYY-MM-DD'),end.format('YYYY-MM-DD'));
     }

      /*for Select Date*/
      var start = moment().subtract(29, 'days');
      var end = moment();
      var startdate=start.format('YYYY-MM-DD');
      var enddate=end.format('YYYY-MM-DD');

   $('#reportrange').daterangepicker({
         startDate: start,
         endDate: end,
         ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment()],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
         }
     }, cb);
   cb(start, end);
   /*date select end*/
   
   function pageLoad(){
     fetch_users_logs(startdate, enddate);
   }
   
   function fetch_users_logs(startdate, enddate){
    task = 'fetch_all_logs';
     $.ajax({
       url: "fetch_log.php",
       type: "POST",
       data: {
         task: task,
         startdate: startdate,
         enddate: enddate
       },
       dataType: 'json',
       success: function(data){
        $('#logintotal').text(data.logs.length);
          display(data.logs);
         // var myJSON = JSON.stringify(data);
                
        var c_per_users = (data.count_per_users);
        var c_per_sp = (data.count_per_sp);

        $('#user').val(c_per_users);
        $('#uidstotal').text(c_per_users.length);

        $('#').val();
        $('#rptotal').text(data.count_per_sp.length);
        

/*priyesh*/
$.each(c_per_sp, function(index, value) {
$('#rp').append('<li>'+
'<div class="col1">'+
'<div class="content">'+
'<div class="content-col1">'+
'<div class="label label-success">'+
'<i class="icon-book">'+
'</i>'+
'</div>'+
'</div>'+
'<div class="content-col2"  >'+
'<div class="desc" id="4">'+ c_per_sp[index].sp +
'</div>'+
'</div>'+
'</div>'+
'</div>'+
'<div class="col2">'+
'<div class="date" id="u3">'+ c_per_sp[index].c +'</div>'
+'</div>'
+'</div>'
);
});


$.each(c_per_users, function(index, value) {
    $('#user').append('<li>'+
'<div class="col1">'+
'<div class="content">'+
'<div class="content-col1">'+
'<div class="label label-danger">'+
'<i class="icon-user">'+
'</i>'+
'</div>'+
'</div>'+
'<div class="content-col2"  >'+
'<div class="desc" id="4">'+ c_per_users[index].user +'</div>'+
'</div>'+
'</div>'+
'</div>'+
'<div class="col2">'+
'<div class="date" id="u3">'+ c_per_users[index].c +'</div>'
+'</div>'
/*+'</div>'*/
+'</li>'
);
    });

  var chart = AmCharts.makeChart("chartdivPublisher", {
        "autoMargins": false,
        "marginTop": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "width":1500,
        "height":500,
        "type": "pie",
        
        "startDuration": 0,
         "theme": "light",
        "addClassNames": true,
        "legend":{
          "position":"bottom",
          "marginRight":50,
          "marginLeft":50,
          "autoMargins":false
    },
    "innerRadius": "0%",
    "defs": {
      "filter": [{
        "id": "shadow",
        "width": "50%",
        "height": "300%",
        "feOffset": {
          "result": "offOut",
          "in": "SourceAlpha",
          "dx": 0,
          "dy": 0
        },
        "feGaussianBlur": {
          "result": "blurOut",
          "in": "offOut",
          "stdDeviation": 5
        },
        "feBlend": {
          "in": "SourceGraphic",
          "in2": "blurOut",
          "mode": "normal"
        }
    }]
  },
  "dataProvider": c_per_sp,
   
  "valueField": "c",
  "titleField": "sp",
  "depth3D": 10,
  "angle": 30,
  "outlineAlpha": 0.1,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
    "fileName": "publisherstats", 
  }
});

var chart = AmCharts.makeChart("chartdivUsers", {
   "autoMargins": false,
  "marginTop": 0,
  "marginBottom": 0,
  "marginLeft": 0,
  "width":1500,
  "height":500,
  "type": "pie",
  "startDuration": 0,
  "theme": "light",
  "addClassNames": true,
  "legend":{
    "position":"bottom",
    "marginRight":50,
    "marginLeft":50,
    "autoMargins":false
  },
  "innerRadius": "0%",
  "defs": {
    "filter": [{
      "id": "shadow",
      "width": "200%",
      "height": "200%",
      "feOffset": {
        "result": "offOut",
        "in": "SourceAlpha",
        "dx": 0,
        "dy": 0
      },
      "feGaussianBlur": {
        "result": "blurOut",
        "in": "offOut",
        "stdDeviation": 5
      },
      "feBlend": {
        "in": "SourceGraphic",
        "in2": "blurOut",
        "mode": "normal"
      }
    }]
  },
  "dataProvider": c_per_users,
  "valueField": "c",
  "titleField": "user",
  "outlineAlpha": 0.1,
  "depth3D": 15,
  "angle": 30,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
     "fileName": "userstats", 
  }
});
/*priyesh*/
     
       }
   
     });
   }
   
   function display(data){
     $('#ex1').DataTable({
             "order": [0, "desc"],
             /*"lengthMenu": [
               [25, 50, 100, -1],
               [25, 50, 100, "All"]
             ],*/
             "autoWidth": true,
             "destroy": true,
             "data": data,
             "columns": [{
               "data": "log_date"
             }, {
               "data": "ip_address"
             }, {
               "data": "user"
             }, {
               "data": "sp"
             }, ],
             dom: 'Bfrtip',
           });
   
     /*ex2*/
     $('#ex2').DataTable({
             "order": [0, "desc"],
             /*"lengthMenu": [
               [25, 50, 100, -1],
               [25, 50, 100, "All"]
             ],*/
             "autoWidth": true,
             "destroy": true,
             "data": data,
             "columns": [{
               "data": "log_date"
             }, {
               "data": "ip_address"
             }, {
               "data": "user"
             }, {
               "data": "sp"
             }, ],
             dom: 'Bfrtip',
           });
   }
   
   $('#logintotal').on('click', function(e){

   });
   
</script>

</html>







