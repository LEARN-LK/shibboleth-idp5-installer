<div id="container">

    <div class="box" style="margin-top: 1px;">
    <?php  if ( isset($_GET['success']) && $_GET['success'] == 1 )
                                      {?>
     
                                        <div class="alert alert-success" >                
                 
                                            <?php echo $_GET['msg']?> 
                                             <a href="index.php"><i class="fa fa-close" style="font-size:18px;color:black;float:right;"></i></a>
                                      <script type="text/javascript">
                                  setTimeout(function(){
                                          window.location = "index.php";
                                        }, 5000);
                                      </script>
                                         
                                </div> 
                        <?php }
         
                            if ( isset($_GET['error']) && $_GET['error'] == 1 )
                                {?>
                                 <div class="alert alert-danger">                
                  
                                <?php echo $_GET['msg']?> 
                                </div> 
                                                                             
                                <?php  }
                                ?>
                              </div>
         
         
<div  id="content">
<div class="container">

<div id="stats">
<div class="col-md-6">
   <div class="widget">
      <div class="widget-content">
         <div class="tabbable tabbable-custom">
            <ul class="nav nav-tabs">
               <li class="active"> <a href="#tab_feed_1" data-toggle="tab">Publisher Statistics</a> </li>
            </ul>
            <div class="tab-content">
               <div class="tab-pane active" id="tab_feed_1">
               
                  <div class="scroller" data-height="300px" data-always-visible="1" data-rail-visible="0">
                     <ul class="feeds clearfix" id="rp"> </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="col-md-6">
   <div class="widget">
      <div class="widget-content">
         <div class="tabbable tabbable-custom">
            <ul class="nav nav-tabs">
               <li class="active"> <a href="#tab_feed_1" data-toggle="tab">User Statistics</a> </li>
            </ul>
            <div class="tab-content">
               <div class="tab-pane active" id="tab_feed_1">
                  <div class="scroller" data-height="300px" data-always-visible="1" data-rail-visible="0">
                     <ul class="feeds clearfix" id="user">

           

                      </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- modal for unique users -->
   <div class="col-md-12">
      <div class="modal fade" id="myModal1">
         <div class="modal-dialog" style="width:80%;">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title">
                     <i class="icon-user">
                     </i> User Statistics
                  </h4>
               </div>
               <div class="modal-body">
                  <div class="widget-content">
                     <div id="chartdivUsers" style="height:1000px; width:100%;"></div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- modal for unique users -->
   <!-- modal for Publisher -->
   <div class="col-md-12">
      <div class="modal fade" id="myModal2">
         <div class="modal-dialog" style="width:80%;">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title">
                     <i class="icon-book">
                     </i> Publisher Statistics
                  </h4>
               </div>
               <div class="modal-body">
                  <div class="widget-content">
                     <div id="chartdivPublisher" style="height:500px;width:100%;"></div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- modal for Publisher -->
   <!-- modal for logs -->
   <div class="col-md-12">
      <div class="modal fade" id="myModal3">
         <div class="modal-dialog" style="width:80%;">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                  <h4 class="modal-title">
                     <i class="icon-user"></i> Total Logs
                  </h4>
               </div>
               <div class="modal-body">
                  <div class="widget-content">
                     <table id="ex2" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
                        <thead style="background: #F9F9F9;">
                           <tr>
                              <th>log_date</th>
                              <th>IP</th>
                              <th>User</th>
                              <th>Publisher</th>
                           </tr>
                        </thead>
                        <tbody> </tbody>
                        <!-- <tfoot> </tfoot> -->
                     </table>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- modal for logs -->
</div>
<div id="dataDiv" class="col-md-12 col-lg-12 col-xs-12"></div>
<div class="col-md-12">
   <div class="widget box">
      <div class="widget-header">
         <h4>
            <i class="icon-lock">
            </i> Log Statistics
         </h4>
      </div>
      <div class="widget-content">
         <div class="tabbable tabbable-custom">
            <ul class="nav nav-tabs">
               <div class="tab-content" style="width: -webkit-fill-available">
                  <div class="tab-pane active" id="tab_feed_1">
                     <table id="ex1" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
                        <thead style="background: #F9F9F9;">
                           <tr>
                              <th>Log date</th>
                              <th>IP</th>
                              <th>User</th>
                              <th>Publisher</th>
                           </tr>
                        </thead>
                        <tfoot> </tfoot>
                        <tbody> </tbody>
                     </table>
                  </div>
               </div>
            </ul>
         </div>
      </div>
   </div>
</div>
</div>
</div>
</div>
</div>

