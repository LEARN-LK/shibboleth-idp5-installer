
<?php
  include 'dbconfig.php';
  // include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
if (isset($_POST['sendmail'])) 
	{
				// echo "<tr>";
				// echo "<th>Email</th>";
				// echo "<th>Status</th>";
				// echo "</tr>";
		
 
		 $handle = fopen($_FILES['filename']['tmp_name'], "r");
		$headers = fgetcsv($handle, 1000, ",");
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{

			
			$mail_address = $data[0];
			$name = $data[1];
			$usernm = $data[2]; 
			$pw = $data[3];
			 $array = [
     'positive' => [],
     'negative' => []
    
 ];
		
			require_once('PHPMailer-master/PHPMailerAutoload.php');
			$mail = new PHPMailer(); // create a new object
			$mail->IsSMTP(); // enable SMTP
			$mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
			$mail->SMTPAuth = true; // authentication enabled
			$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
			$mail->Host = "smtp.office365.com";
			$mail->Port = 587; // or 587
			$mail->IsHTML(true);
			
		    $mail->Username = "infed_noreply@mail.inflibnet.ac.in";
			$mail->Password = "D6R3B5NLn";
			$mail->SetFrom("infed_noreply@mail.inflibnet.ac.in","IGNOU"); 

			$mail->addAddress($mail_address);
			// $mail->addAddress($mail_address);
			$mail->Subject = 'Remote Access to IGNOU Subscribed eResources';
			
			$mail->Body    = "Dear ".$name.", <br><br>
			Greetings from the Dept. of Library, IGNOU. <br><br>
We would like to inform you that the remote access to IGNOU subscribed e-resources has been activated to you through UGC-INFLIBNET's INFED platform.
 <br><br>

Your Remote Access details are:<br>
Remote access link: <a href='https://idp.ignou.ac.in/'>https://idp.ignou.ac.in/</a><br>
User ID: ".$usernm." <br>
Password:".$pw."  <br><br>

Click on the required e-resource, login with this user ID and password. You will be redirected to the
home page of the selected e-resource to search, browse and download the full papers.<br><br>
For any assistance and clarifications, please send a request mail to <a href='librarian@ignou.ac.in'>librarian@ignou.ac.in</a>
<br><br>
Thanks and Regards,<br>
University Librarian<br>
Indira Gandhi National Open University<br>
E-mail: <a href='librarian@ignou.ac.in'>librarian@ignou.ac.in</a>
			
			";
			$mail->AltBody = 'This is a plain text message body';
			$user = $data[0];
			if (!$mail->send()) 
			{
				// echo "hello";
				// array_push($array['negative'], $user, 'Message not sent!');
				// echo "<table>";
				// echo "<tr>";			
				// echo "<td>".$data[0]."</td>";
				// echo '<td> - <b>Message NOT sent!</b></td>';
				// echo "</tr>";
				// echo "</table>";
				// echo 'Mailer Error: ' . $mail->ErrorInfo;
				
				$_SESSION["msg"] = $mail->ErrorInfo. '<br> Please contact Technical person' ;
			} 
			else 
			{	
				// echo "world";
				// array_push($array['positive'], $user, 'Message sent!');
				$_SESSION["msg"] = "Mail successfully sent";
			}
			
		}
fclose($handle);
	}
header("Location:users.php");
?>

