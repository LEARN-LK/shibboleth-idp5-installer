<?php
  include 'dbconfig.php';
  // include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
   ?>
<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
<link rel="stylesheet" href="assets/css/deleteuser.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
</head>
<body >
<div id="main">
  <!--   <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span> -->
<div class="w3-container " >
  <div class=" w3-display-middle w3-card-4 w3-border mobcss" style="box-shadow: 10px 10px 250px #00ADEF;">




  </div>
  
</div>

<h1>Delete Users</h1>
<div class="content">
      

  <div class="bulk">
  <h3>Delete Users in Bulk  <div class="helptip" style="float:right"><i class="fa fa-question-circle" style="font-size:24px;"></i>
  <span class="helptiptext">Here, you can delete the LDAP users in bulk. For format download the sample CSV file</span>
</div></h3>
  <hr>
  
<form enctype='multipart/form-data' action='ldapuser.php' method='post' onSubmit="if(!confirm('Do you want to continue?')){return false;}">
    
<label>CSV File :</label>
 
  <div class="custom-file mb-3">
      <input type="file" id="customFile" name="filename" accept=".csv">
     <!--  <label class="custom-file-label" for="customFile">Choose file</label> -->
    </div>
</br>
 <button type="submit" id="sendbtn" name="sendbtn" class="delete" ><i class="fa fa-trash-o"></i>&emsp;Delete</button>
<a href="assets/files/Delete_user.csv" download class="btn"><i class="fa fa-download"></i> Sample CSV</a>
</form>
</div>
<br>
  <div class="single">
  <h3>Delete a User<div class="helptip" style="float:right"><i class="fa fa-question-circle" style="font-size:24px;"></i>
  <span class="helptiptext">To delete single user from LDAP enter the username</span>
</div></h3>
  <hr>
  
<form enctype='multipart/form-data' action='ldapuser.php' method='post' onSubmit="if(!confirm('Do you want to continue?')){return false;}">
    
<label>Username :</label>
 
  <div class="custom-file mb-3">
      <input type="text" placeholder="Enter username" id="u_name" name="u_name" >
    </div>
</br>
 <button type="submit" id="delbtn" name="delbtn" class="delete" ><i class="fa fa-trash-o"></i>&emsp;Delete</button>

</form>
  </div>


</div>
</div>
</body>
</html>







