<?php
  include 'dbconfig.php';
  // include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
   ?>

<div id="main">
   

<h1>Send Notification</h1>
<div class="content">
	<div class="sendmail">
      
		 <h3>Send Credentials to Users
     <div class="helptip" style="float:right"><i class="fa fa-question-circle" style="font-size:24px;"></i>
  <span class="helptiptext">Here, you can send the login credentials to your LDAP registered users. For format download the sample CSV file</span>
</div></h3>
		 <hr>
<form enctype='multipart/form-data' action='maildata.php' method='post' onSubmit="if(!confirm('Do you want to continue?')){return false;}">
		
<label>CSV file:</label>
 
 
  <div class="custom-file mb-3">
      <input type="file" id="customFile" name="filename" accept=".csv">
     <!--  <label class="custom-file-label" for="customFile">Choose file</label> -->
    </div>
</br>
 <button type="submit" id="sendmail" name="sendmail" class="mail"><i class="fa fa-envelope"></i>&emsp;Send</button>
 <a href="assets/files/mail_user.csv" download class="btn"><i class="fa fa-download"></i> Sample CSV</a>
</form>
</div>
</div>
</div>

