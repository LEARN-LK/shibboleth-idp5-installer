<?php 
session_start();
include 'dbconfig.php';

 if(isset($_POST['addbtn'])){
$pubname    = $_POST['pubname'];

 $publink        = $_POST['publink'];
 $category = $_POST['category'];
 // echo $pubname ;
 // echo  $publink;
 // echo  $category;



 $log_insert_query = "INSERT INTO wayfless (name, link, category) VALUES('$pubname','$publink', '$category')"; 
          $result =  mysqli_query($conn, $log_insert_query);
          echo $result;
if($result){
$_SESSION["msg"] = "<strong>successfully Added</strong>"; 
      // $msg="<strong>successfully Added</strong>";
      Header( 'Location: eresources.php' );

		}

 }
if(isset($_POST['delbtn'])){
$pubname    = $_POST['pubname'];

 $category = $_POST['category'];
 


 $log_delete_query = "DELETE from wayfless WHERE name='$pubname'"; 
          $result =  mysqli_query($conn, $log_delete_query);
          echo $result;
if($result){
$_SESSION["msg"] ="<strong>successfully Deleted</strong>";
      // $msg="<strong>successfully Deleted</strong>";
      Header( 'Location: eresources.php' );

            }

 }

?>