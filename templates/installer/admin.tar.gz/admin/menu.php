<?php
  include 'dbconfig.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    header( 'Location: login.php' );
   }
   ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="assets/css/header.css">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <link rel="stylesheet" href="assets/css/export.css" type="text/css" media="all" />
      <link href="assets/css/main.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/plugins.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
      <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
      <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/css/stats.css">
<link rel="stylesheet" href="assets/css/home.css">
<link rel="stylesheet" href="assets/css/style1.css">
<link rel="stylesheet" href="assets/css/deleteuser.css">
<script type="text/javascript" src="assets/js/stats.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/mail.css">
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->
<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->

</head>
<body>
 <div class="container-fluid p-0" style="background-image: linear-gradient(#f3d797, #ffb700);">
        <nav class="navbar navbar-expand-lg  navbar-light py-3 py-lg-0 px-lg-5" style="background-image: linear-gradient(#f3d797, #ffb700);border: none;">
            <a href="index.html" class="navbar-brand ml-lg-3">

               <img src ="../../assets/images/logo.png"  width="15%" />
            </a>
          
                <div class="navbar-nav mx-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>


                    <div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn nav-item nav-link" style="font-size:18px;background-image: linear-gradient(#f3d797, #ffb700);border: none;">Admin<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content">
     <a href = "changepassword.php" style="font-size: 16px;color: black;" >Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" >Logout</a>
 
  </div>
</div>
              
                </div>
              
        </nav>
    </div>

<!-- <div class="blue-bg">
  <img src="../assets/images/logo.png"/ class="logo">
</div>
<div class="white-bg shadow"></div> -->
<!-- 
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script> -->
   



<script src="assets/js/amcharts.js"></script>
<script src="assets/js/pie.js"></script>
<script src="assets/js/serial.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.12/sorting/datetime-moment.js"></script>

<script type="text/javascript" src="plugins/datatables/jquery.dataTables.min.js"></script>

<script src="assets/js/export.min.js"></script>

<script src="assets/js/light.js"></script>

<script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js">
</script>
<script type="text/javascript" src="plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js">
</script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js">
</script>
<script type="text/javascript" src="assets/js/libs/lodash.compat.min.js">
</script>

<script type="text/javascript" src="plugins/touchpunch/jquery.ui.touch-punch.min.js"></script>
<script type="text/javascript" src="plugins/event.swipe/jquery.event.move.js"></script>
<script type="text/javascript" src="plugins/event.swipe/jquery.event.swipe.js"></script>
<script type="text/javascript" src="assets/js/libs/breakpoints.js"></script>
<script type="text/javascript" src="plugins/respond/respond.min.js"></script>
<script type="text/javascript" src="plugins/cookie/jquery.cookie.min.js"></script>
<script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.horizontal.min.js"></script>

<script type="text/javascript" src="plugins/sparkline/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="plugins/daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="plugins/daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="plugins/blockui/jquery.blockUI.min.js"></script>
<script type="text/javascript" src="plugins/uniform/jquery.uniform.min.js"></script>
<script type="text/javascript" src="plugins/select2/select2.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js">
</script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js ">
</script>

<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/plugins.js"></script>
<script type="text/javascript" src="assets/js/plugins.form-components.js"></script>
<script>$(document).ready(function(){App.init();Plugins.init();FormComponents.init()});</script>
<script type="text/javascript" src="assets/js/custom.js"></script>

