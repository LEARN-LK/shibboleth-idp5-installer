<?php
session_start();
include 'dbconfig.php';
//include 'log_Model.php';

$data = array();

$logs = array();
$count_per_users= array();
$count_per_sp = array();

$task = (isset($_POST) && isset($_POST['task'])) ? $_POST['task'] : '';

$sdate= (isset($_POST['startdate'])) ? $_POST['startdate'] : '';
$edate=(isset($_POST['enddate'])) ? $_POST['enddate'] : '';

$startdate=date("Y-m-d H:i:s", strtotime($sdate));
$enddate=date("Y-m-d H:i:s", strtotime($edate));

switch ($task) {
	case "fetch_all_logs":
		$logs = fetch_logs($conn, $startdate, $enddate);
		$count_per_users = per_users($conn, $startdate, $enddate);
		$count_per_sp = per_sp($conn, $startdate, $enddate);

		$data['logs'] = $logs;
		$data['count_per_users'] = $count_per_users;
		$data['count_per_sp'] = $count_per_sp;
		
		echo json_encode($data);
		break;
}

function fetch_logs($conn, $startdate, $enddate){
	// SELECT * FROM `userstats` WHERE log_date BETWEEN '2020-06-01 12:40:32' AND '2020-07-16 12:40:32'
	$fetch_sql = "SELECT id, log_date, user, sp, ip_address FROM userstats WHERE log_date BETWEEN '$startdate' AND '$enddate' " ;
	//$fetch_sql= "SELECT id, log_date, user, sp, ip_address FROM userstats ";
	$result = mysqli_query($conn,$fetch_sql);
	//$rows = mysqli_fetch_object($result);
	$rows = $result->fetch_all(MYSQLI_ASSOC);
	//print_r($rows); die;
	return $rows;
}

//for per users count
function per_users($conn, $startdate, $enddate){
	$user_sql= "SELECT user, COUNT(user) as c
				FROM userstats
				WHERE log_date BETWEEN '$startdate' AND '$enddate'
				GROUP BY user
				";
	$result = mysqli_query($conn,$user_sql);
	$rows = $result->fetch_all(MYSQLI_ASSOC);
	return $rows;
}

//for per service provider PUBLISHER count
function per_sp($conn, $startdate, $enddate){
	$sp_sql="SELECT sp, COUNT(sp) as c
				FROM userstats
				WHERE log_date BETWEEN '$startdate' AND '$enddate'
				GROUP BY sp
				";
				$result = mysqli_query($conn,$sp_sql);
	$rows = $result->fetch_all(MYSQLI_ASSOC);
	return $rows;
}

?>