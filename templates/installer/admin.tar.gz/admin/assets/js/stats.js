function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}



  function closemsg (){
msg = document.getElementById("success_msg");
msg.style.display = "none";

}
/* When the user clicks on the button, 
toggle between hiding and showing the dropadown content */
function myFunction() {
  document.getElementById("mydropadown").classList.toggle("show");
}

// Close the dropadown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropabtn')) {
    var dropadowns = document.getElementsByClassName("dropadown-content");
    var i;
    for (i = 0; i < dropadowns.length; i++) {
      var opendropadown = dropadowns[i];
      if (opendropadown.classList.contains('show')) {
        opendropadown.classList.remove('show');
      }
    }
  }
}