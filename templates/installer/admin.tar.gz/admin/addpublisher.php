<?php
  include 'dbconfig.php';
  include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
   ?>





<!-- <h1 class="headings">Publisher Details</h1> -->
</div>

<div class="box" >
   

<div class="content">

<!-- <div class="tab box"> -->

<div class="msg-container" id="msg">

    <?php if(isset($_SESSION["msg"])){ ?>
    <div class="msg-box" id="success_msg" >
      <h4><?php echo $_SESSION["msg"];?><i class = "fa fa-close" style="float: right" onclick="closemsg()"></i></h4>
        <?php unset($_SESSION["msg"]) ?>
    </div>
    <?php } ?>
    </div>

	<!-- <button class="tablinks" style="float: right;"><a href="logout.php"><i class="fa fa-sign-out" style="font-size: 24px;color: black;" ></i></a></button> -->
    <!--  <button class="tablinks" style="float: right;">  <a href="index.php"><i class="fa fa-home" style="font-size: 24px;color: black;" ></i></a></button>
<div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn"><i class="fa fa-user"></i>&nbsp;Admin&nbsp;<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content">
     <a href = "changepassword.php" style="font-size: 16px;color: black;" ><i class="fa fa-key" ></i>Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" ><i class="fa fa-sign-out" ></i>Logout</a>
 
  </div>
</div> -->

     
<!-- </div> -->
<div class="single" style="margin-top: 1%">
   
  <h3>Add Publisher</h3>
  <hr>
  
<form class="form-vertical login-form" action="logics.php"  method="POST">

<div class="alert fade in alert-danger" style="display: none;">
<i class="icon-remove close" data-dismiss="alert">
</i> Enter any publisher name . </div>
<div class="form-group">
<div class="input-icon">
<i class="icon-user">
</i>
<input type="text" class="form-control" placeholder="Enter Publisher Name" id="pubname" name="pubname" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter Enter Publisher Name."/>
</div>
</div>

<div class="form-group">
<div class="input-icon">
<i class="fa fa-globe">
</i>
<input type="text" class="form-control" placeholder="Enter Publisher Entity ID/Link " id="publink" name="publink" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter Enter Publisher URL."/>
</div>
</div>


<button type="submit" name="addnew" class="add"> Submit </button>

</form>
  </div>
</div>

</body>
<script type="text/javascript">
   
function closemsg (){
msg = document.getElementById("success_msg");
msg.style.display = "none";

}
</script>

</html>







