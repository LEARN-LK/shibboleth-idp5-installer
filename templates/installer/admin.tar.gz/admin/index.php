<?php
  include 'dbconfig.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    header( 'Location: login.php' );
   }
   ?>
<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">


    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

   

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/style1.css" rel="stylesheet">
    <link href="assets/css/stats.css" rel="stylesheet">
</head>

<body>
   
    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 px-lg-5">
            <a href="index.html" class="navbar-brand ml-lg-3">
               <!--  <h1 class="m-0 text-uppercase text-primary"><i class="fa fa-book-reader mr-3"></i>Edukate</h1> -->
               <img src ="../../assets/images/logo.png"  width="15%" />
            </a>
          
                <div class="navbar-nav mx-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>


                    <div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn nav-item nav-link">Admin<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content">
     <a href = "changepassword.php" style="font-size: 16px;color: black;" >Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" >Logout</a>
 
  </div>
</div>
              
                </div>
              
        </nav>
    </div>
    <!-- Navbar End -->


    <!-- Header Start -->
    <div class="jumbotron jumbotron-fluid page-header position-relative overlay-bottom" style="margin-bottom: 90px;">
        <!-- <div class="container text-center py-5">
            <h1 class="text-white display-1">Indira Gandhi National Open University</h1>
         
        </div> -->
         <div class="container py-5">
            <div class="row">
               
                    <div class="d-flex mb-3">
                        <div class="btn-icon bg-primary mr-4">
                            <i class="fa fa-2x fa-chart-pie text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h3><a href="statistics.php">Statistics</a></h3>
                            <p><b>It shows the user statistics (to which publisher they had traverse through IDP page).</b></p>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="btn-icon bg-secondary mr-4">
                            <i class="fa fa-2x fa-users text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h3> <a href="users.php">User Management</a></h3>
                            <p><b>In this section you can add users through LDAP, delete a single user and in bulk too. Here you can send notification mail also to registered users</b></p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <div class="btn-icon bg-warning mr-4">
                            <i class="fa fa-2x fa-sticky-note text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h3><a href="eresources.php">IDP page Management</a></h3>
                            <p class="m-0"><b>In this section you add your E-resources for IDP page</b></p>
                        </div>
                    </div>
               
            </div>
        </div>
    </div>
   




    <!-- Footer Start -->
   
    <!-- Footer End -->


    <!-- Back to Top -->
   <!--  <a href="#" class="btn btn-lg btn-primary rounded-0 btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a> -->


 
</body>
<script type="text/javascript" src="assets/js/stats.js"></script>
</html>