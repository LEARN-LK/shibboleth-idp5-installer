


<!-- <h1>Publisher Details</h1> -->

<div class="box" >
    <div class="page-header">
        <div class="col-sm-6 col-md-2 hidden-xs" >
            <div class="statbox widget box box-shadow">
                <div class="widget-content">
                        <div class="visual green"><i class="icon-book"></i></div>
                        <div class="title">Total Publishers</div>
                            <div class="value" >

                                        <?php
                                        $sql = "SELECT * from univspdetails";

                                        if ($result = mysqli_query($conn, $sql)) {

                                            $rowcount = mysqli_num_rows( $result );

                                            printf($rowcount);
                                         }

                                        ?>
                             </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="widget box">
                <div class="widget-header">
                    <h4><i class="icon-book"></i> Publisher Details</h4>
                </div>
                <div class="widget-content">
                    <div class="tabbable tabbable-custom">
                        <ul class="nav nav-tabs">
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_feed_1">
                                    <form action="addpublisher.php" method="POST">
                                        <button type="submit" name="addnew" class="submit btn btn-primary" style="float: left; background: rgb(231,233,235);color: black;margin-bottom: 5px"><i class="fa fa-plus"> Add new</i></button>
                                    </form>
                                     
                                      <table id="ex1" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
                                            <thead style="background: #F9F9F9;">
                                                        <tr>
                                                        <th >Publisher</th>
                                                        <th >Entity ID</th>  
                                                        <th >Action</th>  
                
                                                        </tr>
                                            </thead>
        
                                            <tbody>
                                                     <?php 
                                                        $sql = 'SELECT * FROM univspdetails ORDER BY spname ';

                                                        $retval = mysqli_query($conn,$sql);

                                                        if(! $retval ) {
                                                            die('Could not get data: ' . mysql_error());
                                                        }

                                                        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
                                                            ?>  
                                                <tr>
                                                <td name="spname" id="spname"><?php echo $row['spname'] ?></td>
                                                <td ><?php echo $row['entityid'] ?></td>

                                                <td style="text-align: center">
                    <a href="editpublisher.php?spname=<?php echo $row['spname']; ?>"><i class="fa fa-pencil" style=" color:green;font-size:15px"></i></a>&emsp;
             
 <a href="logics.php?id=<?php echo $row['id']?>&delete=1"><i class="glyphicon glyphicon-trash" style="margin-left:5px; color:#E61919;font-size:15px;" onClick="return confirm('Are you sure to delete <?php echo $row['spname']?> ?')"></i> </a></td>


</td>

                                                 </tr>
                            <?php         
                        }
                        
                        ?>   

                                             </tbody>
                                        </table>
                                </div>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>