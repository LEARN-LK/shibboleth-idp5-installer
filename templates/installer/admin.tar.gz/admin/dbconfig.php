<?php
                $dbhost = 'localhost'; 
                $dbuser = 'root'; 
                $dbpass = 'Admin@123'; 
                $db='stats'; 
                $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db); 

                if(! $conn ) {
                  die('Could not connect: ' . mysqli_error());
               }
             
?>