<div id="container">

    <div class="box" >
 
         
         
<div id="content">
<div class="container" scroll="no">

<div class="row  row-bg">
  <!--  <div class="col-sm-6 col-md-4 hidden-xs" data-toggle="modal" data-target="#myModal1">
      <div class="statbox widget box box-shadow">
         <div class="widget-content">
            <div class="visual green"> <i class="icon-user">
               </i> 
            </div>
            <div class="title">Unique Users</div>
            <div class="value" id="uidstotal">0</div>
            <a class="more" role="dialog" data-show="modal" data-target="#myModal1">View More <i class="pull-right icon-angle-right">
            </i>
            </a> 
         </div>
      </div>
   </div> -->

   <div class="col-sm-6 col-md-4 hidden-xs" data-toggle="modal" data-target="#myModal3">
      <div class="statbox widget box box-shadow">
         <div class="widget-content">
            <div class="visual red"> <i class="icon-lock">
               </i> 
            </div>
            <div class="title">Total Logins</div>
            <div class="value" id="logintotal">0</div>
            <a class="more" data-show="modal" data-target="#myModal3">View More <i class="pull-right icon-angle-right">
            </i>
            </a> 
         </div>
      </div>
   </div>
</div>


<!-- publisher garph -->
<div class="col-sm-6 col-md-4 " >
<div class="statbox widget box box-shadow">
         <div class="widget-content">
            <div class="visual yellow"> <i class="icon-book">
               </i> 
            </div>
            <div class="title">Unique Publishers</div>
            <div class="value" id="rptotal">0</div>
         </div>
      </div>
   </div>
<div class="widget-content">
                     <div id="chartdivPublisher" style="height:600px;width:100%;"></div>
                  </div>
                  <hr>
<br/>
<!-- user graph -->
 <div class="col-sm-6 col-md-4" >
      <div class="statbox widget box box-shadow">
         <div class="widget-content">
        <div class="visual green"> <i class="icon-user">
               </i> 
            </div>
            <div class="title">Unique Users</div>
            <div class="value" id="uidstotal">0</div>
         
         </div>
      </div>
   </div>
  <div class="widget-content">
                     <div id="chartdivUsers" style="height:600px; width:100%;"></div>
                  </div>



   <div class="col-md-12">
      <div class="modal fade" id="myModal1">
         <div class="modal-dialog" style="width:80%;">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title">
                     <i class="icon-user">
                     </i> User Statistics
                  </h4>
               </div>
               <div class="modal-body">
                  <div class="widget-content">
                     <div id="chartdivUsers" style="height:1000px; width:100%;"></div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- modal for unique users -->
   <!-- modal for Publisher -->
   <div class="col-md-12">
      <div class="modal fade" id="myModal2">
         <div class="modal-dialog" style="width:80%;">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title">
                     <i class="icon-book">
                     </i> Publisher Statistics
                  </h4>
               </div>
               <div class="modal-body">
                  <div class="widget-content">
                     <div id="chartdivPublisher" style="height:500px;width:100%;"></div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
   </div>

   <!-- modal for Publisher -->
   <!-- modal for logs -->
   <div class="col-md-12">
      <div class="modal fade" id="myModal3">
         <div class="modal-dialog" style="width:80%;">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                  <h4 class="modal-title">
                     <i class="icon-user"></i> Total Logs
                  </h4>
               </div>
               <div class="modal-body">
                  <div class="widget-content">
                     <table id="ex2" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
                        <thead style="background: #F9F9F9;">
                           <tr>
                              <th>log_date</th>
                              <th>IP</th>
                              <th>User</th>
                              <th>Publisher</th>
                           </tr>
                        </thead>
                        <tbody> </tbody>
                        <!-- <tfoot> </tfoot> -->
                     </table>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- modal for logs -->
</div>

</div> </div></div>


<script>
   $(document).ready(function(){

    $.ajax({
      url:"getcontent.php",
      method: "POST",
      success: function(){
        task = 'fetch_all_logs';
        pageLoad();
      }
    });
       //pageLoad();
   });

/*date select start*/
   function cb(start, end) {
         $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
         document.getElementById("user").innerHTML = "";
           document.getElementById("rp").innerHTML = "";
         fetch_users_logs(start.format('YYYY-MM-DD'),end.format('YYYY-MM-DD'));
     }

      /*for Select Date*/
      var start = moment().subtract(29, 'days');
      var end = moment();
      var startdate=start.format('YYYY-MM-DD');
      var enddate=end.format('YYYY-MM-DD');

   $('#reportrange').daterangepicker({
         startDate: start,
         endDate: end,
         ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment()],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
         }
     }, cb);
   cb(start, end);
   /*date select end*/
   
   function pageLoad(){
     fetch_users_logs(startdate, enddate);
   }
   
   function fetch_users_logs(startdate, enddate){
    task = 'fetch_all_logs';
     $.ajax({
       url: "fetch_log.php",
       type: "POST",
       data: {
         task: task,
         startdate: startdate,
         enddate: enddate
       },
       dataType: 'json',
       success: function(data){
        $('#logintotal').text(data.logs.length);
          display(data.logs);
         // var myJSON = JSON.stringify(data);
                
        var c_per_users = (data.count_per_users);
        var c_per_sp = (data.count_per_sp);

        $('#user').val(c_per_users);
        $('#uidstotal').text(c_per_users.length);

        $('#').val();
        $('#rptotal').text(data.count_per_sp.length);
        

/*priyesh*/
$.each(c_per_sp, function(index, value) {
$('#rp').append('<li>'+
'<div class="col1">'+
'<div class="content">'+
'<div class="content-col1">'+
'<div class="label label-success">'+
'<i class="icon-book">'+
'</i>'+
'</div>'+
'</div>'+
'<div class="content-col2"  >'+
'<div class="desc" id="4">'+ c_per_sp[index].sp +
'</div>'+
'</div>'+
'</div>'+
'</div>'+
'<div class="col2">'+
'<div class="date" id="u3">'+ c_per_sp[index].c +'</div>'
+'</div>'
+'</div>'
);
});


$.each(c_per_users, function(index, value) {
    $('#user').append('<li>'+
'<div class="col1">'+
'<div class="content">'+
'<div class="content-col1">'+
'<div class="label label-danger">'+
'<i class="icon-user">'+
'</i>'+
'</div>'+
'</div>'+
'<div class="content-col2"  >'+
'<div class="desc" id="4">'+ c_per_users[index].user +'</div>'+
'</div>'+
'</div>'+
'</div>'+
'<div class="col2">'+
'<div class="date" id="u3">'+ c_per_users[index].c +'</div>'
+'</div>'
/*+'</div>'*/
+'</li>'
);
    });

  var chart = AmCharts.makeChart("chartdivPublisher", {
        "autoMargins": false,
        "marginTop": 0,
        "marginBottom": 0,
        "marginLeft": 0,
        "width":1500,
        "height":500,
        "type": "pie",
        
        "startDuration": 0,
         "theme": "light",
        "addClassNames": true,
        "legend":{
          "position":"bottom",
          "marginRight":50,
          "marginLeft":50,
          "autoMargins":false
    },
    "innerRadius": "0%",
    "defs": {
      "filter": [{
        "id": "shadow",
        "width": "50%",
        "height": "300%",
        "feOffset": {
          "result": "offOut",
          "in": "SourceAlpha",
          "dx": 0,
          "dy": 0
        },
        "feGaussianBlur": {
          "result": "blurOut",
          "in": "offOut",
          "stdDeviation": 5
        },
        "feBlend": {
          "in": "SourceGraphic",
          "in2": "blurOut",
          "mode": "normal"
        }
    }]
  },
  "dataProvider": c_per_sp,
   
  "valueField": "c",
  "titleField": "sp",
  "depth3D": 10,
  "angle": 30,
  "outlineAlpha": 0.1,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
    "fileName": "publisherstats", 
  }
});

var chart = AmCharts.makeChart("chartdivUsers", {
   "autoMargins": false,
  "marginTop": 0,
  "marginBottom": 0,
  "marginLeft": 0,
  "width":1500,
  "height":500,
  "type": "pie",
  "startDuration": 0,
  "theme": "light",
  "addClassNames": true,
  "legend":{
    "position":"bottom",
    "marginRight":50,
    "marginLeft":50,
    "autoMargins":false
  },
  "innerRadius": "0%",
  "defs": {
    "filter": [{
      "id": "shadow",
      "width": "200%",
      "height": "200%",
      "feOffset": {
        "result": "offOut",
        "in": "SourceAlpha",
        "dx": 0,
        "dy": 0
      },
      "feGaussianBlur": {
        "result": "blurOut",
        "in": "offOut",
        "stdDeviation": 5
      },
      "feBlend": {
        "in": "SourceGraphic",
        "in2": "blurOut",
        "mode": "normal"
      }
    }]
  },
  "dataProvider": c_per_users,
  "valueField": "c",
  "titleField": "user",
  "outlineAlpha": 0.1,
  "depth3D": 15,
  "angle": 30,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
     "fileName": "userstats", 
  }
});
/*priyesh*/
     
       }
   
     });
   }
   
   function display(data){
     $('#ex1').DataTable({
             "order": [0, "desc"],
             /*"lengthMenu": [
               [25, 50, 100, -1],
               [25, 50, 100, "All"]
             ],*/
             "autoWidth": true,
             "destroy": true,
             "data": data,
             "columns": [{
               "data": "log_date"
             }, {
               "data": "ip_address"
             }, {
               "data": "user"
             }, {
               "data": "sp"
             }, ],
             dom: 'Bfrtip',
           });
   
     /*ex2*/
     $('#ex2').DataTable({
             "order": [0, "desc"],
             /*"lengthMenu": [
               [25, 50, 100, -1],
               [25, 50, 100, "All"]
             ],*/
             "autoWidth": true,
             "destroy": true,
             "data": data,
             "columns": [{
               "data": "log_date"
             }, {
               "data": "ip_address"
             }, {
               "data": "user"
             }, {
               "data": "sp"
             }, ],
             dom: 'Bfrtip',
           });
   }
   
   $('#logintotal').on('click', function(e){

   });
   
</script>

